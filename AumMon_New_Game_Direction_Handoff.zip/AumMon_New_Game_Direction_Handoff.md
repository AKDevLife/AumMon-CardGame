# AumMon — New Game Direction Handoff

**Document type:** Game Design Direction & Project Transition Brief  
**Purpose:** ให้ Claude ตรวจสอบแนวทางเกมใหม่ เปรียบเทียบกับเอกสารและโค้ดในโปรเจกต์ แล้ววางแผนปรับใช้โดยไม่ทำลายระบบเดิมก่อนการอนุมัติ  
**Status:** Proposal / Direction Brief — ยังไม่ใช่ Game Spec ฉบับอนุมัติ  
**Language:** Thai (technical terms remain in English)

---

## 1. คำสั่งสำคัญสำหรับการใช้เอกสารนี้

เอกสารนี้รวบรวมแนวทางใหม่ที่ผู้ใช้ได้เลือกไว้ รวมถึงข้อเสนอจากการออกแบบในบทสนทนา แต่ **ไม่ใช่คำสั่งให้แก้โค้ดหรือเขียนทับ Game Spec ทันที**

Claude ต้องดำเนินการตามลำดับนี้:

1. อ่านเอกสารนี้ให้ครบ
2. ตรวจสอบเอกสารทั้งหมดใน repository ที่เกี่ยวข้อง โดยเฉพาะ Game Spec, Project Handoff, CLAUDE.md, Recipe Library, Keyword/Effect Engine Specification, database schema, migrations, API และ implementation ปัจจุบัน
3. แยกข้อเท็จจริงที่มีอยู่ในโปรเจกต์ออกจากข้อเสนอในเอกสารนี้
4. วิเคราะห์ผลกระทบและความขัดแย้งอย่างเป็นระบบ
5. จัดทำแผนย้ายทิศทางเกมและรายการเอกสาร/ระบบที่ต้องปรับ
6. **หยุดรอการอนุมัติจากผู้ใช้ก่อนแก้ไข Game Spec, database, migrations, application code หรือไฟล์ authoritative ใด ๆ**

ห้ามอ้างว่าได้ตรวจสอบไฟล์ใดแล้ว หากยังไม่ได้เปิดอ่านไฟล์นั้นจริง หากข้อมูลไม่ตรงกัน ให้รายงานความแตกต่างพร้อมอ้าง path และหัวข้อ/บรรทัดที่เกี่ยวข้อง

---

## 2. ภาพรวมทิศทางเกมใหม่

### 2.1 แนวคิดหลัก

**AumMon — Everyday Objects Battle**

เกม Digital Trading Card Game แบบ 1v1 ที่นำสิ่งของธรรมดาในชีวิตประจำวันมาทำให้มีชีวิต มีใบหน้า แขนขา บุคลิก และความสามารถเฉพาะตัวที่สัมพันธ์กับคุณสมบัติหรือหน้าที่ของสิ่งของนั้น

ตัวอย่างประเภทสิ่งของ:
- Stationery: ดินสอ ปากกา ยางลบ ไม้บรรทัด
- Containers: กระเป๋า กล่อง ขวด
- Vehicles: รถยนต์ รถจักรยาน
- Machines: เครื่องตัดหญ้า เครื่องซักผ้า
- Electronics: นาฬิกาปลุก โทรศัพท์ วิทยุ
- Tools: ค้อน ไขควง ประแจ
- Household: พัดลม โคมไฟ เก้าอี้
- Sharp Objects และหมวดอื่น ๆ ตามความเหมาะสม

หมวดหมู่เหล่านี้เป็นเครื่องมือช่วยจัดระบบการออกแบบและค้นหา Synergy ไม่จำเป็นต้องเป็นกฎที่ผู้เล่นต้องจดจำ เว้นแต่ภายหลังจะพบว่ามีประโยชน์ต่อ gameplay จริง

### 2.2 จุดขายที่ต้องการ

- ผู้เล่นเห็นแล้วเข้าใจได้ทันทีว่าวัตถุคือตัวอะไร
- ตัวละครมีบุคลิกและเอกลักษณ์จากสิ่งของต้นแบบ
- ความสามารถในเกมควรเชื่อมโยงกับคุณสมบัติ หน้าที่ หรือภาพจำของสิ่งของ
- การ์ดแต่ละใบต้องแตกต่างด้าน gameplay ไม่ใช่ต่างกันแค่ภาพและชื่อ
- เข้าใจง่ายพอสำหรับผู้เล่นใหม่ แต่ยังมีพื้นที่ให้วางแผนและสร้าง Deck Strategy

### 2.3 สิ่งที่ยกเลิกจากทิศทางเดิม

แนวทางใหม่กำหนดว่า:
- ใช้ **Object Cards เท่านั้น**
- ไม่มี Evolution
- ไม่มี Fusion
- ไม่มี Equipment
- หนึ่งการ์ดแทนหนึ่งตัวละคร (**One Card, One Character**)
- ไม่ใช้ Fusion เป็นจุดขายหลักอีกต่อไป

การยกเลิกข้างต้นเป็นทิศทางการออกแบบที่ผู้ใช้เลือกแล้ว แต่ Claude ต้องตรวจสอบ implementation และเอกสารจริงก่อนสรุปขอบเขตการลบ/ย้ายระบบ

---

## 3. การตัดสินใจที่ผู้ใช้ยืนยันแล้ว

| หัวข้อ | ตัวเลือกที่ยืนยัน | ความหมาย |
|---|---|---|
| Card Types | A — Object Cards only | ใช้การ์ดตัวละครที่เป็นสิ่งของมีชีวิตเท่านั้น |
| Art Direction | A — Living Objects | สิ่งของมีใบหน้าและแขนขา มีบุคลิกชัดเจน |
| Core Rules | A — Preserve core structure | รักษาโครงสร้าง 1v1, SPARK, HP, Ready/Exhausted และปรับเท่าที่จำเป็น |
| Ability System | B — Passive + Active | Object Card อาจมี Passive, Active หรือทั้งสองแบบ |

**ข้อสำคัญ:** การเลือก Passive + Active เป็นการยืนยันรูปแบบระบบความสามารถโดยรวม ไม่ได้แปลว่าผู้ใช้อนุมัติรายละเอียดกฎย่อยทุกข้อของ Active Ability แล้ว

---

## 4. Core Gameplay ที่ต้องรักษาไว้เป็นหลัก

ทิศทางใหม่ต้องพยายามรักษาแกน gameplay เดิม:
- 1v1 TCG
- SPARK เป็นทรัพยากรหลัก
- HP เป็นเงื่อนไขความอยู่รอด/ชัยชนะตามกติกาปัจจุบัน
- Object มีสถานะ Ready และ Exhausted
- การโจมตีและการป้องกันยังต้องเชื่อมกับ Ready/Exhausted
- ปรับเฉพาะกฎที่จำเป็นต่อการรองรับแนวทาง Object Cards และ Ability System ใหม่

อย่าคิดตัวเลขหรือเขียนกฎใหม่จากความจำ ให้ตรวจสอบ Game Spec ฉบับที่อยู่ใน repository ก่อนเสมอ

### 4.1 Guard / Ready / Exhausted — ประเด็นที่เคยเสนอ

แนวคิดที่เคยหารือ:
- Object ที่ Ready สามารถใช้ Guard ป้องกันได้
- เมื่อ Object โจมตีและกลายเป็น Exhausted จะไม่สามารถใช้ Guard ได้ในช่วงที่ Exhausted
- Exhausted จนถึง Start Phase ถัดไปของเจ้าของ ตามกติกาที่ต้องตรวจสอบกับ Game Spec
- หากไม่มี Guard ที่ Ready ฝ่ายตรงข้ามเลือกเป้าหมายโจมตีได้ตามกติกาปกติ

ให้ Claude ตรวจสอบว่าแนวคิดนี้ตรงกับกติกาปัจจุบันหรือไม่ และรายงานผลกระทบ ห้ามถือว่าข้อความนี้เป็นการอนุมัติแก้ Core Rules โดยอัตโนมัติ

---

## 5. Object Card Design

### 5.1 ข้อมูลการ์ดที่เสนอ

Object Card อาจประกอบด้วย:
- Name
- Cost
- ATK
- DEF
- HP
- Ability หรือ Abilities
- Rarity
- Traits
- Flavor Text

รายการนี้เป็นข้อเสนอด้านโครงสร้างข้อมูล ต้องเทียบกับ Data Model และ UI ปัจจุบันก่อนกำหนดเป็น schema จริง

### 5.2 หลักการออกแบบตัวละคร

1. ความสามารถต้องสัมพันธ์กับวัตถุต้นแบบ
2. ชื่อ Ability ควรสื่อภาพจำของสิ่งของ
3. แต่ละใบควรมี gameplay identity ที่ชัดเจน
4. อย่าให้การ์ดจำนวนมากใช้ Effect เดียวกันโดยเปลี่ยนเพียงชื่อ/ภาพ
5. ความสามารถและ Stats ต้องประเมินร่วมกันเป็น Power Budget
6. ความหายากไม่ควรเป็นตัวกำหนดว่าการ์ดต้องเก่งกว่าเสมอ

ตัวอย่างความเชื่อมโยง:
- Pencil: ความแม่นยำ การขีดเขียน การทำเครื่องหมาย
- Backpack: การเก็บของ การปกป้อง การพกพา
- Sports Car: ความเร็ว การเร่งเครื่อง การพุ่งโจมตี
- Alarm Clock: การปลุก การเตือน การหยุด/ชะลอจังหวะ

---

## 6. Ability System — Passive + Active

### 6.1 ประเภทหลัก

**Passive Ability**
ความสามารถที่ทำงานอัตโนมัติตามเงื่อนไขหรือ Event

แบ่งเป็น:
- **Static Passive:** มีผลต่อเนื่องตราบเท่าที่เงื่อนไขเป็นจริง
- **Triggered Passive:** ทำงานเมื่อเกิด Trigger/Event ที่กำหนด

**Active Ability**
ความสามารถที่ผู้เล่นเลือกสั่งใช้ โดยต้องระบุค่าใช้จ่าย Timing เงื่อนไขเป้าหมาย และข้อจำกัดการใช้ให้ชัดเจน

Ability เป็นส่วนหนึ่งของ Object Card ไม่ใช่ Card Type ใหม่

### 6.2 Active Ability — กฎตั้งต้นที่เสนอ แต่ยังไม่อนุมัติ

ข้อเสนอ default ที่ควรนำไปวิเคราะห์:
- ใช้ได้ใน Main Phase ของเจ้าของ
- Object ต้นทางต้อง Ready
- จ่าย SPARK ตาม Cost ของ Ability
- เมื่อใช้ Ability ให้ Exhaust Object ต้นทาง
- ใช้ได้ไม่เกิน 1 ครั้งต่อเทิร์นต่อการ์ด
- ตรวจสอบ Target และเงื่อนไขให้ถูกต้องก่อนจ่าย Cost
- เมื่อจ่าย Cost แล้วจึงเข้าสู่ขั้น Resolution
- Timing พิเศษ เช่น ใช้ระหว่าง Combat ควรเป็นข้อยกเว้นที่ระบุไว้เฉพาะ Ability

**สถานะ:** ยังเป็น Design Proposal เท่านั้น โดยเฉพาะกฎ “ใช้ Active แล้ว Exhaust source” ต้องให้ผู้ใช้อนุมัติก่อนนำไปล็อกใน Game Spec หรือ implementation

เหตุผลที่เสนอ Exhaust source:
- สร้างทางเลือกเชิงกลยุทธ์ระหว่างการโจมตีกับการใช้ Active
- ทำให้ Ready/Exhausted มีความหมายเชื่อมโยงกัน
- ลดโอกาสใช้ Active โดยไม่มี Opportunity Cost

Claude ควรวิเคราะห์ทางเลือกอื่นด้วย เช่น Active ที่ไม่ Exhaust, มี Cooldown/Once per turn, หรือใช้ Cost สูงขึ้น แล้วเปรียบเทียบข้อดีข้อเสียและความซับซ้อน

### 6.3 Design Rules

- การ์ดทั่วไปควรมีความสามารถหลักหนึ่งอย่าง
- บางใบเป็น Passive only
- บางใบเป็น Active only
- บางใบมีทั้ง Passive และ Active
- Dual Ability ต้องคิด Power Budget รวม ไม่ใช่แจกความสามารถเพิ่มฟรี
- Active ต้องระบุ Cost, Timing, Limit และ Target
- Passive ต้องระบุ Trigger, Condition และผลลัพธ์
- ทุก Effect ควรระบุ Duration, Stacking และข้อจำกัดเมื่อเกี่ยวข้อง
- ต้องป้องกัน Trigger ซ้ำและ Infinite Loop
- ต้องกำหนดการทำงานเมื่อ Source ออกจากสนามหรือ Target หายไป

### 6.4 ตัวอย่าง Ability — ใช้เพื่อทดสอบแนวคิดเท่านั้น

**Sports Car**
- Passive: Speed Demon — เมื่อโจมตี ได้รับ +1 ATK ตามช่วงเวลาที่กำหนด
- Active: Turbo Boost — จ่าย 1 SPARK และ Exhaust เพื่อรับ +2 ATK จนจบเทิร์น

**Pencil**
- Passive: Precision — ตัวอย่างความสามารถที่เชื่อมโยงกับความแม่นยำ

**Backpack**
- Passive: Pack Protection — ตัวอย่างความสามารถด้านการปกป้อง
- Active: Emergency Storage — จ่าย 1 SPARK และ Exhaust เพื่อฟื้น HP 1 ให้ Object ฝ่ายเรา

**Alarm Clock**
- Passive: Wake Up — ตัวอย่างความสามารถเมื่อเกิดเหตุการณ์เริ่มเทิร์น
- Active: Snooze — จ่าย 1 SPARK และ Exhaust เพื่อ Exhaust Object ฝ่ายตรงข้ามที่ Ready

ตัวอย่างเหล่านี้ยังไม่ผ่าน Balance Test และไม่ใช่การ์ดที่อนุมัติแล้ว ตัวเลขและข้อความต้องออกแบบใหม่ให้เข้ากับกติกาจริง

---

## 7. Effect Engine — ผลกระทบที่ต้องตรวจสอบ

ไม่ควรเขียน Effect Engine ใหม่ทั้งหมดโดยไม่มีเหตุผล ให้ตรวจสอบระบบเดิมและพิจารณาต่อยอดเท่าที่จำเป็น

### 7.1 Flow ที่คาดหวัง

Passive:
1. Game Event
2. Detect Passive Trigger
3. Validate Conditions
4. Resolve Effect
5. State-Based Check

Active:
1. Player Selects Ability
2. Validate Source / Ready / Timing / Target / Limit
3. Pay SPARK and any required Cost
4. Apply Exhaust or other activation cost (หากกฎสุดท้ายกำหนด)
5. Resolve Effect
6. State-Based Check

### 7.2 Events ที่ควรตรวจสอบว่ารองรับหรือจำเป็นต้องเพิ่ม

- ON_TURN_START
- ON_SUMMON
- ON_ATTACK_DECLARE
- ON_DAMAGE
- ON_DESTROY
- ON_ACTIVE_ABILITY
- ON_TURN_END

ชื่อ Event เป็นตัวอย่างเชิงแนวคิด ต้องเทียบ naming convention ของ Engine จริงก่อนนำไปใช้

### 7.3 ระบบเดิมที่เคยพบใน Project Handoff

จากข้อมูลที่เคยอ่านในส่วน Keyword & Effect Engine Specification มีองค์ประกอบดังนี้ (ต้องตรวจซ้ำกับไฟล์ล่าสุด):
- Trigger Detection
- Condition Validation
- Effect Queue
- Effect Resolution
- State-Based Check

รายการ Keyword ที่เคยปรากฏ:
- Haste
- Guard
- Flying
- Piercing
- Overclock
- Reinforce
- Draw
- Search
- Recycle
- Modular
- Ancient
- Unstable

รายการ Trigger Events ที่เคยปรากฏ:
- ON_GAME_START
- ON_TURN_START
- ON_DRAW
- ON_SUMMON
- ON_ENTER_FIELD
- ON_ATTACK_DECLARE
- ON_COMBAT_START
- ON_DAMAGE
- ON_DESTROY
- ON_EVOLVE
- ON_FUSION
- ON_EQUIP
- ON_EQUIPMENT_LOST
- ON_CARD_DISCARD
- ON_TURN_END

Effect Types ที่เคยปรากฏ:
- MODIFY_STAT
- DEAL_DAMAGE
- HEAL
- DRAW_CARD
- SEARCH_CARD
- RECYCLE_CARD
- SUMMON_UNIT
- DESTROY_UNIT
- EXHAUST_UNIT
- READY_UNIT
- ADD_KEYWORD
- REMOVE_KEYWORD
- ATTACH_EQUIPMENT
- MOVE_ZONE
- MODIFY_COST
- EVOLVE_UNIT
- FUSION_UNIT

รายการข้างต้นเป็นข้อมูลจากการตรวจอ่านก่อนหน้า ไม่ใช่การยืนยันว่า repository ปัจจุบันยังมีทั้งหมดหรือทำงานครบถ้วน

### 7.4 งานตรวจสอบ Engine

Claude ต้อง:
- ตรวจสอบ Trigger/Event/Effect ที่มีการใช้งานจริง
- ระบุส่วนที่รองรับ Object-only ได้อยู่แล้ว
- ระบุส่วนที่ผูกกับ Evolution/Fusion/Equipment
- แยก “ลบได้”, “ต้อง refactor”, “เก็บไว้ใช้ต่อ”, “ยังไม่แน่ใจ”
- ตรวจสอบ Event ordering, resolution priority, re-entrancy, loop prevention และ state-based checks
- ตรวจสอบผลต่อ server authority และ validation ฝั่ง backend
- ไม่ลบโค้ดหรือ migration ก่อนมีแผนและการอนุมัติ

---

## 8. Power Budget และ Balance Framework

ประเมินความแข็งแกร่งจากผลรวม:
- Base Stats
- Passive Ability
- Active Ability
- ความถี่ในการทำงาน
- Trigger และเงื่อนไข
- SPARK Cost
- Exhaust/Opportunity Cost
- Target restrictions
- Duration และ Stacking
- Synergy กับการ์ดอื่น

กรอบ Impact เบื้องต้น:
- **Light:** ผลเล็กหรือเกิดในเงื่อนไขจำกัด
- **Medium:** มีผลต่อการแลกเปลี่ยนหรือ tempo อย่างมีนัยสำคัญ
- **Heavy:** เปลี่ยนสถานการณ์เกมหรือสร้างความได้เปรียบสูง

อย่าใช้ Impact Level เป็นสูตรตายตัว ต้องทดสอบด้วย Playtest และข้อมูลจริง

หลักสำคัญ:
- Dual Ability ไม่ควรเหนือกว่าการ์ด Ability เดียวในทุกสถานการณ์
- ความสามารถที่มีผลบ่อยต้องคิดต้นทุนมากกว่าความสามารถที่เกิดยาก
- Active ที่ใช้แทนการโจมตีมี Opportunity Cost หาก Exhaust source เป็นกฎจริง
- ต้องทดสอบความคุ้มค่าของ SPARK และผลต่อ tempo
- Balance Stats และ Ability พร้อมกัน ห้ามปรับแยกโดยไม่ดูผลรวม

---

## 9. Prototype Plan — 24 Cards

ข้อเสนอสำหรับ Prototype ชุดแรก: 24 ใบ

### 9.1 การกระจายตาม Ability Type

| Ability Type | จำนวน |
|---|---:|
| Passive Only | 8 |
| Active Only | 8 |
| Dual Ability | 8 |
| **รวม** | **24** |

### 9.2 การกระจายตาม Archetype

| Archetype | จำนวน |
|---|---:|
| Aggro | 6 |
| Defensive | 6 |
| Control | 6 |
| Synergy | 6 |
| **รวม** | **24** |

แนวทางกระจายเบื้องต้น: แต่ละ Archetype มี Passive Only 2 ใบ, Active Only 2 ใบ และ Dual Ability 2 ใบ

ต้องตรวจสอบว่า Archetype ไม่กลายเป็นข้อจำกัดตายตัว และการ์ดหนึ่งใบอาจสนับสนุนมากกว่าหนึ่งแนวทางได้หากเหมาะสม

### 9.3 ก่อนขยายเป็น 24 ใบ

ควรสร้างและตรวจสอบ Framework ด้วยการ์ดตัวอย่าง 6 ใบก่อน เพื่อทดสอบ:
- ความชัดเจนของ Object Identity
- ความหลากหลายของ Ability
- ความสมเหตุสมผลของ Passive/Active
- ความสมดุลของ Stats และ Cost
- ความครอบคลุมของ Effect Engine
- ความเข้าใจของผู้เล่น

เมื่อ Framework ผ่านการตรวจสอบจึงค่อยขยายเป็น Prototype 24 ใบ

---

## 10. Playtest และ Validation

ต้องมีทั้งการทดสอบกติกาและการทดสอบระบบ

### 10.1 Test Areas

- Activation Opportunity: ใช้ Active คุ้มกว่าหรือด้อยกว่าการโจมตีหรือไม่
- Ability vs Attack: การเลือกใช้ Active ทำให้เกิดการตัดสินใจจริงหรือไม่
- Spark Pressure: SPARK Cost สร้างแรงกดดันและข้อจำกัดเหมาะสมหรือไม่
- Dual Ability Value: การ์ดที่มีสองความสามารถเกิน Power Budget หรือไม่
- Object Identity: ความสามารถสะท้อนสิ่งของจริงและทำให้จำการ์ดได้หรือไม่
- Archetype Diversity: ทั้ง 4 Archetypes มีแผนการเล่นที่แตกต่างกันจริงหรือไม่
- Complexity: ผู้เล่นใหม่เข้าใจการ์ดและ Timing ได้หรือไม่

### 10.2 Test Cases สำหรับ Active / Passive

- Source เป็น Ready และ Exhausted
- SPARK เพียงพอและไม่เพียงพอ
- ใช้ Ability ซ้ำในเทิร์นเดียว
- Target ไม่ถูกต้องหรือหายไปก่อน Resolve
- Passive Trigger หลายรายการเกิดพร้อมกัน
- Trigger ทำให้เกิด Trigger ต่อเนื่อง
- ตรวจสอบ Infinite Loop
- Object HP เหลือ 0 และการทำลาย
- Source ออกจากสนามระหว่าง Resolution
- การจ่าย Cost และการ Resolve ต้องไม่เกิดซ้ำเมื่อ request ถูกส่งซ้ำ

---

## 11. Roadmap ที่เสนอ

1. **Design Foundation** — ยืนยันหลักการ Object-only, Living Objects, Core Rules และ Ability Framework
2. **Prototype Framework** — สร้าง Template, Power Budget, Validation Rules และตัวอย่าง 6 ใบ
3. **Prototype Expansion** — ออกแบบชุด 24 ใบ
4. **Rules Validation** — ตรวจความสอดคล้องของกติกาและ interaction
5. **Playtest** — ทดสอบความสนุก ความเข้าใจ ความสมดุล และความหลากหลาย
6. **Game Spec Revision** — ปรับ Game Spec ให้เป็นแหล่งอ้างอิงหลักฉบับใหม่ หลังอนุมัติ
7. **Technical Impact Review** — สรุปผลกระทบต่อ Architecture, Database, API, Security, Effect Engine, UI และ Test Suite
8. **Implementation Plan** — แบ่งงาน migration/refactor/deletion/addition เป็น phase พร้อม acceptance criteria
9. **Implementation** — เริ่มแก้โค้ดและข้อมูลหลังได้รับอนุมัติ
10. **Regression & Release Validation** — ทดสอบระบบเดิมที่ยังต้องคงอยู่และระบบใหม่ทั้งหมด

---

## 12. เอกสารและระบบใน Repository ที่ Claude ต้องตรวจสอบ

ตรวจสอบตามที่มีอยู่จริง:
- `Game Spec v3.0` หรือ Game Spec ฉบับล่าสุด
- `AumMon_Master_Project_Handoff.md`
- `CLAUDE.md`
- Recipe Library
- Keyword & Effect Engine Specification
- Architecture / Database / Security specifications
- Database schema และ migrations
- Card definitions / seed data / card catalog
- Effect and keyword registries
- Backend game logic / validation
- Frontend card rendering / gameplay UI
- Test suites / fixtures / sample decks
- Deployment configuration ที่เกี่ยวข้อง หากมีผลกับการเปลี่ยนระบบ

อย่าคิดว่าไฟล์เหล่านี้มีอยู่ทั้งหมด ให้ค้นหา repository และรายงานชื่อ/path จริง

---

## 13. สิ่งที่ยังไม่อนุมัติหรือยังต้องตัดสินใจ

รายการนี้สำคัญมาก ห้าม Claude ตีความว่าเป็นข้อสรุปที่ล็อกแล้ว:

1. Active Ability ต้อง Exhaust source หรือไม่
2. Active ใช้ได้เฉพาะ Main Phase หรือมี Fast/Combat Timing ด้วย
3. Active จำกัดหนึ่งครั้งต่อเทิร์นต่อการ์ดหรือใช้ข้อจำกัดแบบอื่น
4. Active ทุกใบต้องมี SPARK Cost หรือมี Cost แบบอื่นได้
5. Object Card มี Ability ได้สูงสุดกี่รายการ
6. Stats และ Card Fields ขั้นสุดท้าย
7. Keyword ใดควรเก็บ ปรับชื่อ รวม หรือถอด
8. Trait มีผลต่อกติกาหรือเป็นเพียง metadata
9. รายละเอียด Core Rules ที่ต้องเปลี่ยนจาก Game Spec ปัจจุบัน
10. จำนวนการ์ดและการกระจาย Rarity ในชุด Prototype/ชุดเปิดตัว
11. Power Budget แบบตัวเลขและสูตร Balance
12. Data Schema และ API Contract ฉบับใหม่

Claude ควรเสนอทางเลือก พร้อมข้อดี ข้อเสีย ความซับซ้อน และผลกระทบ ก่อนขออนุมัติ

---

## 14. ข้อกำหนดการทำงานของ Claude

- ใช้ repository ปัจจุบันเป็นแหล่งข้อเท็จจริงด้าน implementation
- ใช้เอกสารนี้เป็นทิศทางการออกแบบใหม่ ไม่ใช่หลักฐานว่าโค้ดรองรับแล้ว
- รักษาเอกสาร authoritative ให้มีแหล่งอ้างอิงเดียวและไม่ขัดแย้งกัน
- ห้ามแก้ Game Spec, Handoff, CLAUDE.md, Recipe Library, Database, migrations หรือ source code ในรอบตรวจสอบแรก
- ห้ามลบระบบ Evolution/Fusion/Equipment ทันที ให้ทำ impact inventory ก่อน
- ห้ามสร้าง migration หรือ commit เพื่อเปลี่ยนระบบโดยไม่ได้รับอนุมัติ
- ห้ามเดาตัวเลขกติกาจากข้อความในเอกสารนี้ ให้ตรวจ Game Spec
- ทุกข้อเสนอใหม่ต้องติดป้าย `PROPOSED`
- สิ่งที่ผู้ใช้เลือกแล้วให้ติดป้าย `USER-CONFIRMED DIRECTION`
- สิ่งที่ตรวจสอบจาก repository แล้วให้ติดป้าย `VERIFIED IN REPOSITORY` พร้อม path
- สิ่งที่ยังไม่ทราบให้ติดป้าย `NEEDS VERIFICATION`
- เมื่อพบความขัดแย้ง ให้รายงานก่อนแก้ไข
- ส่งรายงานภาษาไทยที่อ่านง่าย มี technical details เท่าที่จำเป็น

---

## 15. ผลลัพธ์ที่ต้องการจากการตรวจสอบรอบแรก

Claude ต้องส่งมอบรายงานโดยยังไม่แก้ไขไฟล์หรือโค้ด ประกอบด้วย:

1. **Repository Audit:** ไฟล์และระบบที่เกี่ยวข้อง พร้อมสถานะจริง
2. **Current vs New Direction Matrix:** ตารางเทียบระบบเดิมกับทิศทางใหม่
3. **Conflict & Risk Register:** จุดขัดแย้ง ความเสี่ยง และผลกระทบ
4. **Keep / Modify / Remove / Add Inventory:** รายการระบบที่ควรเก็บ ปรับ ถอด หรือเพิ่ม พร้อมเหตุผล
5. **Ability Framework Review:** แนวทาง Passive/Active, Timing, Cost, Exhaust และข้อเสนอทางเลือก
6. **Effect Engine Impact:** Event, Trigger, Effect, Resolver และ State-Based Check ที่ได้รับผลกระทบ
7. **Data & Database Impact:** Card schema, migrations, seed data, API และ validation
8. **Document Update Plan:** ไฟล์เอกสารที่จะต้องแก้และลำดับการแก้
9. **Implementation Roadmap:** Phase, dependencies, acceptance criteria และ test strategy
10. **Open Decisions:** คำถามที่ผู้ใช้ต้องตัดสินใจ โดยจัดลำดับตามความสำคัญ

ปิดท้ายด้วยคำแนะนำว่าเริ่มจากงานใด และรอการอนุมัติจากผู้ใช้ก่อนเริ่มเปลี่ยนแปลงจริง

---

## 16. สรุปสั้นที่สุด

ทิศทางใหม่ของ AumMon คือ **เกม 1v1 TCG ที่ใช้สิ่งของในชีวิตประจำวันเป็นตัวละครมีชีวิต โดยมี Object Cards เท่านั้น และใช้ Passive + Active Abilities เป็นเครื่องมือสร้างเอกลักษณ์ของการ์ด** รักษาแกน 1v1, SPARK, HP, Ready/Exhausted ไว้ให้มากที่สุด ยกเลิกแนวคิด Evolution, Fusion และ Equipment ในทิศทางการออกแบบใหม่

ขั้นตอนต่อไปไม่ใช่การเขียนโค้ดทันที แต่คือให้ Claude ตรวจ repository จริง วิเคราะห์ความขัดแย้งและผลกระทบ วางแผนปรับเอกสารและระบบ แล้วรอผู้ใช้อนุมัติก่อนดำเนินการ
